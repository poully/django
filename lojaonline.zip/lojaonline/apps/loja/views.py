from django.shortcuts import render
from .models import Produto, Fabricante

# Create your views here.

def produtos(request):
    template_name = 'loja/produtos.html'
    produtos = Produto.objects.all()
    context = {
        'produtos' : produtos
    }
    return render(request, template_name,context)


def fabricantes(request):
    template_name = 'loja/fabricantes.html'
    fabricantes = Fabricante.objects.all()
    context = {
        'fabricantes' : fabricantes
    }
    return render(request, template_name,context)

def produto(request, id_produto):
    template_name = 'loja/produto.html'
    produto = Produto.objects.get(id=id_produto)
    context = {
        'produto' : produto}
    return render(request, template_name,context)


def fabricante(request, id_fabricante):
    template_name = 'loja/fabricante.html'
    fabricante = Fabricante.objects.get(id=id_fabricante)
    context = {
        
        'fabricante' : fabricante
    }
    return render(request, template_name,context)    