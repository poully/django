from django.contrib import admin
from django.contrib.auth.models import Group
from .models import Produto
from .models import Fabricante

admin.site.register(Produto)
admin.site.register(Fabricante)


admin.site.site_header = 'Opções'
admin.site.index_title = 'Produtos - Loja'
