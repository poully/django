from django.urls import path
from loja import views

app_name = 'loja'

urlpatterns = [
    path('produtos/', views.produtos, name = 'produtos'),
    path('produto/<int:id_produto>/', views.produto, name = 'produto'),


    path('fabricantes/', views.fabricantes, name = 'fabricantes'),
    path('fabricante/<int:id_fabricante>/', views.fabricante, name = 'fabricante'),
]    