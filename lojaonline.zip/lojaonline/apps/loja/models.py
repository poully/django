from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Produto(models.Model):
    produto = models.CharField('Produto',max_length=120)
    descricao = models.TextField('Descrição', blank=True, null=True)
    preco = models.FloatField('Preço')
    taxa_envio = models.FloatField('Taxa de envio')
    quantidade = models.IntegerField('Quantidade')


    def __str__(self):
        return self.produto


class Fabricante(models.Model):
    nome = models.CharField('Nome',max_length=120)
    localizacao = models.CharField('Lozalização',max_length=120)
    ativo = models.BooleanField('Ativo')

    def __str__(self):
        return self.nome